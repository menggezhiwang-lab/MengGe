let thatData = objMonitor(wm.thatData);

if(!sessionStorage.userId){
    window.location.href = 'index.html';
}

//导入多语言翻译文案
for(let i in dataObj.history){
    thatData[i] = dataObj.history[i];
}

thatData.upDate({
    imageBack: '',
    prev: 'src/history/prev.png',
    next: 'src/history/next.png',
    currentPage: 1,
    totalPage: 0,
})

let imageArray = [];

ajax({
    url: wm.URLS + '/board-center/roomController/getCloudShareBackup',
    data: {
        roomId: sessionStorage.roomId,
    },
    dataType: 'json',
    success: function(data){
        if(data.code == 200){
            for(let i of data.data.imgUrls.split(',')){
                imageArray.push(i);
            }
            thatData.imageBack = 'url(' + imageArray[0] + ')';
            thatData.totalPage = imageArray.length;
        }
    }
})

c('controller_prev')[0].Click(function(){
    if(thatData.currentPage > 1){
        thatData.currentPage--;
        thatData.prev = 'src/history/prevs.png';
    }
},function(){
    thatData.prev = 'src/history/prev.png';
    thatData.imageBack = 'url(' + imageArray[thatData.currentPage-1] + ')';
},true)
c('controller_next')[0].Click(function(){
    if(thatData.currentPage < imageArray.length){
        thatData.currentPage++;
        thatData.next = 'src/history/nexts.png';
    }
},function(){
    thatData.next = 'src/history/next.png';
    thatData.imageBack = 'url(' + imageArray[thatData.currentPage-1] + ')';
},true)

c('controller_down')[0].Click(function(){
    d('download').href = imageArray[thatData.currentPage-1];
    d('download').click();
});